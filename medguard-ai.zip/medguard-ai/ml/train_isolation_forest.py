"""Train an Isolation Forest on SYNTHETIC baseline vitals.

IMPORTANT: this data is synthetic and exists to demonstrate the pipeline.
The result is NOT clinical validation. Replace with representative, ethically
collected data before drawing any conclusion about detection performance.

Run from the repo root:  python ml/train_isolation_forest.py
"""
import os

import joblib
import numpy as np
from sklearn.ensemble import IsolationForest

rng = np.random.default_rng(42)
normal = np.column_stack([
    rng.normal(75, 8, 3000),      # heart rate, bpm
    rng.normal(97, 1.0, 3000),    # SpO2, %
    rng.normal(36.6, 0.3, 3000),  # temperature, C
])
model = IsolationForest(n_estimators=200, contamination=0.01, random_state=42).fit(normal)

anomalies = np.column_stack([
    rng.uniform(130, 190, 300), rng.uniform(78, 90, 300), rng.uniform(38.5, 40.5, 300)])
holdout = np.column_stack([
    rng.normal(75, 8, 1000), rng.normal(97, 1.0, 1000), rng.normal(36.6, 0.3, 1000)])

print("Synthetic evaluation only (not clinical validation)")
print(f"  Flagged synthetic anomalies: {(model.predict(anomalies) == -1).mean():.1%}")
print(f"  Flagged synthetic normals (false positives): {(model.predict(holdout) == -1).mean():.1%}")

out = os.path.join(os.path.dirname(__file__), "models")
os.makedirs(out, exist_ok=True)
joblib.dump(model, os.path.join(out, "isoforest.joblib"))
print(f"Saved model to {os.path.join(out, 'isoforest.joblib')}")
