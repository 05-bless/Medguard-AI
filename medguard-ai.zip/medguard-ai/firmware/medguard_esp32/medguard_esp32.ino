/*
 * MedGuard AI - ESP32 firmware (prototype)
 *
 * STATUS: written to match the server's message format, but NOT yet compiled
 * or tested on hardware. Start with SIMULATE_SENSORS 1 to verify the secure
 * pipeline end to end, then implement the real sensor reads (see TODO).
 *
 * Features: signed messages (HMAC-SHA256), sequence counter that survives
 * reboots, local alerts, and an offline queue that syncs after reconnection.
 * Research prototype, not a medical device.
 */
#include <WiFi.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <mbedtls/md.h>
#include <time.h>
#include "config.h"

#define SIMULATE_SENSORS 1      // 1 = generate fake readings; 0 = use real sensors
#define SEND_INTERVAL_MS 2000
#define QUEUE_SIZE 200          // readings kept in RAM while offline
#define BUFFERED_AFTER_S 30     // older than this => sent as "buffered"
#define SEQ_BLOCK 100           // flash write once per block, not per message

const int PIN_BUZZER = 25, PIN_LED_OK = 26, PIN_LED_ALERT = 27;

// Illustrative thresholds, matching server/classifier.py. Not clinical limits.
const int HR_LOW = 50, HR_HIGH = 120, SPO2_LOW = 92, SIGQ_MIN = 50;
const float TEMP_LOW = 35.0, TEMP_HIGH = 38.0;

struct Sample { uint32_t seq; uint32_t ts; int hr, spo2; float temp; int motion, sigq; };

Sample queue_[QUEUE_SIZE];
int qHead = 0, qCount = 0;
uint32_t nextSeq = 0, seqWatermark = 0;
Preferences prefs;

// ---- Sequence counter: independent of the clock, survives reboots ----
// On boot we resume from a saved watermark, so numbers may skip ahead. The
// server logs this as a SEQUENCE_GAP event, which is expected and harmless.
void initSeq() {
  prefs.begin("medguard", false);
  nextSeq = prefs.getUInt("wm", 0);
  seqWatermark = nextSeq + SEQ_BLOCK;
  prefs.putUInt("wm", seqWatermark);
}
uint32_t takeSeq() {
  if (nextSeq >= seqWatermark) { seqWatermark += SEQ_BLOCK; prefs.putUInt("wm", seqWatermark); }
  return nextSeq++;
}

// ---- HMAC-SHA256 over the canonical string (must match server/security.py) ----
String hmacHex(const String &msg) {
  uint8_t out[32];
  mbedtls_md_context_t ctx;
  mbedtls_md_init(&ctx);
  mbedtls_md_setup(&ctx, mbedtls_md_info_from_type(MBEDTLS_MD_SHA256), 1);
  mbedtls_md_hmac_starts(&ctx, (const unsigned char *)DEVICE_KEY, strlen(DEVICE_KEY));
  mbedtls_md_hmac_update(&ctx, (const unsigned char *)msg.c_str(), msg.length());
  mbedtls_md_hmac_finish(&ctx, out);
  mbedtls_md_free(&ctx);
  String hex;
  char b[3];
  for (int i = 0; i < 32; i++) { sprintf(b, "%02x", out[i]); hex += b; }
  return hex;
}

String buildJson(const Sample &s, int buffered) {
  char temp[12];
  snprintf(temp, sizeof(temp), "%.1f", s.temp);
  String canon = String(DEVICE_ID) + "|" + s.seq + "|" + s.ts + "|" + s.hr + "|" + s.spo2 + "|" +
                 temp + "|" + s.motion + "|" + s.sigq + "|" + buffered;
  String json = String("{\"device_id\":\"") + DEVICE_ID + "\",\"seq\":" + s.seq + ",\"ts\":" + s.ts +
                ",\"hr\":" + s.hr + ",\"spo2\":" + s.spo2 + ",\"temp\":" + temp +
                ",\"motion\":" + s.motion + ",\"sig_q\":" + s.sigq + ",\"buffered\":" + buffered +
                ",\"hmac\":\"" + hmacHex(canon) + "\"}";
  return json;
}

// ---- Sensors ----
bool readSensors(Sample &s) {
#if SIMULATE_SENSORS
  s.hr = 72 + random(-4, 5);
  s.spo2 = 97 + random(-1, 2);
  s.temp = 36.6 + random(-3, 4) / 10.0;
  s.motion = 0;
  s.sigq = 90;
  if (random(0, 20) == 0) { s.hr = 150; }                 // occasional abnormal value
  if (random(0, 25) == 0) { s.motion = 1; s.sigq = 30; }  // occasional motion artifact
  return true;
#else
  // TODO: MAX30102 (I2C 0x57): collect red/IR samples and estimate HR and SpO2 with
  //       the SparkFun MAX3010x library's heartRate / spo2_algorithm. Set s.sigq from
  //       signal amplitude (0-100).
  // TODO: DS18B20 on PIN 4 via OneWire + DallasTemperature -> s.temp.
  // TODO: MPU6050 (I2C 0x68): set s.motion = 1 when acceleration variance exceeds a threshold.
  return false;
#endif
}

// ---- Local alerts: work with or without the network ----
void localAlert(const Sample &s) {
  bool bad = s.hr < HR_LOW || s.hr > HR_HIGH || s.spo2 < SPO2_LOW || s.temp < TEMP_LOW || s.temp > TEMP_HIGH;
  // A noisy reading (motion / low quality) must not silence a possible emergency:
  // abnormal values alert regardless of signal quality.
  digitalWrite(PIN_LED_ALERT, bad ? HIGH : LOW);
  digitalWrite(PIN_LED_OK, bad ? LOW : HIGH);
  digitalWrite(PIN_BUZZER, bad ? HIGH : LOW);
}

// ---- Offline queue ----
void enqueue(const Sample &s) {
  if (qCount == QUEUE_SIZE) { qHead = (qHead + 1) % QUEUE_SIZE; qCount--; }  // drop oldest
  queue_[(qHead + qCount) % QUEUE_SIZE] = s;
  qCount++;
}
// TODO: persist the queue to LittleFS so readings survive a reboot during an outage.

bool post(const String &json) {
  if (WiFi.status() != WL_CONNECTED) return false;
  HTTPClient http;
  http.begin(SERVER_URL);
  http.addHeader("Content-Type", "application/json");
  int code = http.POST(json);
  http.end();
  // 200 = accepted. 409 = server already has it (replay): drop it, do not retry forever.
  return code == 200 || code == 409;
}

void flushQueue() {
  while (qCount > 0) {
    const Sample &s = queue_[qHead];
    time_t now = time(nullptr);
    int buffered = (s.ts == 0 || (now > 100000 && (long)(now - s.ts) > BUFFERED_AFTER_S)) ? 1 : 0;
    if (!post(buildJson(s, buffered))) return;  // still offline; keep the rest
    qHead = (qHead + 1) % QUEUE_SIZE;
    qCount--;
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(PIN_BUZZER, OUTPUT); pinMode(PIN_LED_OK, OUTPUT); pinMode(PIN_LED_ALERT, OUTPUT);
  initSeq();
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  configTime(0, 0, "pool.ntp.org");
}

void loop() {
  static uint32_t last = 0;
  if (millis() - last < SEND_INTERVAL_MS) return;
  last = millis();

  Sample s;
  if (!readSensors(s)) return;
  time_t now = time(nullptr);
  s.ts = now > 100000 ? (uint32_t)now : 0;  // 0 = clock not synced yet
  s.seq = takeSeq();

  localAlert(s);
  enqueue(s);
  flushQueue();
  Serial.printf("seq=%u hr=%d spo2=%d temp=%.1f queued=%d wifi=%d\n",
                s.seq, s.hr, s.spo2, s.temp, qCount, WiFi.status() == WL_CONNECTED);
}
