// Copy this file to config.h and edit. config.h is git-ignored: never commit real credentials.
#pragma once
#define WIFI_SSID    "your-wifi-name"
#define WIFI_PASS    "your-wifi-password"
#define SERVER_URL   "http://192.168.1.10:5000/ingest"  // your computer's LAN IP
#define DEVICE_ID    "esp32-01"                          // must match server/keys.json
#define DEVICE_KEY   "change-me-to-a-long-random-string" // must match server/keys.json
