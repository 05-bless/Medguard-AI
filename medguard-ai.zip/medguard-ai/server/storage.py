"""SQLite storage: readings, per-device sequence state, hash-chained audit log."""
import hashlib
import sqlite3
import threading

GENESIS = "0" * 64


class Storage:
    def __init__(self, path=":memory:"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        with self.lock:
            self.conn.executescript("""
            CREATE TABLE IF NOT EXISTS readings(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              device_id TEXT, seq INTEGER, ts INTEGER, received_at REAL,
              hr INTEGER, spo2 INTEGER, temp REAL, motion INTEGER,
              sig_q INTEGER, buffered INTEGER, status TEXT, detail TEXT);
            CREATE TABLE IF NOT EXISTS device_state(
              device_id TEXT PRIMARY KEY, last_seq INTEGER);
            CREATE TABLE IF NOT EXISTS events(
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              received_at REAL, device_id TEXT, kind TEXT, detail TEXT,
              prev_hash TEXT, hash TEXT);
            """)

    def last_seq(self, device_id):
        with self.lock:
            row = self.conn.execute(
                "SELECT last_seq FROM device_state WHERE device_id=?",
                (device_id,)).fetchone()
        return row["last_seq"] if row else -1

    def accept(self, p, now, status, detail):
        """Store an accepted reading and advance the device's sequence."""
        with self.lock:
            self.conn.execute(
                "INSERT INTO readings(device_id,seq,ts,received_at,hr,spo2,temp,"
                "motion,sig_q,buffered,status,detail) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (p["device_id"], p["seq"], p["ts"], now, p["hr"], p["spo2"],
                 p["temp"], p["motion"], p["sig_q"], p["buffered"], status, detail))
            self.conn.execute(
                "INSERT INTO device_state(device_id,last_seq) VALUES(?,?) "
                "ON CONFLICT(device_id) DO UPDATE SET last_seq=excluded.last_seq",
                (p["device_id"], p["seq"]))
            self.conn.commit()

    @staticmethod
    def _hash(prev, received_at, device_id, kind, detail):
        payload = f"{prev}|{received_at}|{device_id}|{kind}|{detail}"
        return hashlib.sha256(payload.encode()).hexdigest()

    def add_event(self, kind, device_id, detail, now):
        """Append to the tamper-evident log (each row hashes the previous one)."""
        now = float(now)  # stored as REAL, so hash the float form
        device_id = str(device_id)[:32]
        detail = str(detail)[:200]
        with self.lock:
            row = self.conn.execute(
                "SELECT hash FROM events ORDER BY id DESC LIMIT 1").fetchone()
            prev = row["hash"] if row else GENESIS
            h = self._hash(prev, now, device_id, kind, detail)
            self.conn.execute(
                "INSERT INTO events(received_at,device_id,kind,detail,prev_hash,hash)"
                " VALUES(?,?,?,?,?,?)", (now, device_id, kind, detail, prev, h))
            self.conn.commit()

    def verify_chain(self):
        """Return (ok, first_bad_event_id). Detects edited or deleted rows."""
        with self.lock:
            rows = self.conn.execute("SELECT * FROM events ORDER BY id").fetchall()
        prev = GENESIS
        for r in rows:
            expected = self._hash(prev, r["received_at"], r["device_id"],
                                  r["kind"], r["detail"])
            if r["prev_hash"] != prev or r["hash"] != expected:
                return False, r["id"]
            prev = r["hash"]
        return True, None

    def recent(self, table, limit=50):
        assert table in ("readings", "events")
        limit = max(1, min(int(limit), 500))
        with self.lock:
            rows = self.conn.execute(
                f"SELECT * FROM {table} ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [dict(r) for r in rows]
