"""Event classification: health alert vs sensor fault.

Thresholds are ILLUSTRATIVE and configurable. They are not clinical limits.

Safety rule: a low-quality or motion-affected reading NEVER silences a
possibly abnormal value. If a reading is both suspect and abnormal, the
result is ALERT_LOW_CONFIDENCE, which still raises an alert.
"""
DEFAULTS = {
    "hr_low": 50, "hr_high": 120,
    "spo2_low": 92,
    "temp_low": 35.0, "temp_high": 38.0,
    "sig_q_min": 50,
}
PLAUSIBLE = {"hr": (20, 250), "spo2": (50, 100), "temp": (20.0, 45.0)}

NORMAL = "NORMAL"
HEALTH_ALERT = "HEALTH_ALERT"
SENSOR_FAULT = "SENSOR_FAULT"
ALERT_LOW_CONFIDENCE = "ALERT_LOW_CONFIDENCE"
REVIEW = "REVIEW"


def classify(p, th=None, anomaly_flag=False):
    th = th or DEFAULTS
    faults, abnormal = [], []

    if p["motion"]:
        faults.append("motion detected")
    if p["sig_q"] < th["sig_q_min"]:
        faults.append("low signal quality")
    for key, (lo, hi) in PLAUSIBLE.items():
        if not lo <= p[key] <= hi:
            faults.append(f"{key} physically implausible")

    if p["hr"] < th["hr_low"] or p["hr"] > th["hr_high"]:
        abnormal.append(f"heart rate {p['hr']} bpm outside range")
    if p["spo2"] < th["spo2_low"]:
        abnormal.append(f"SpO2 {p['spo2']}% below threshold")
    if p["temp"] < th["temp_low"] or p["temp"] > th["temp_high"]:
        abnormal.append(f"temperature {p['temp']:.1f} C outside range")

    if faults and abnormal:
        return ALERT_LOW_CONFIDENCE, abnormal + faults
    if faults:
        return SENSOR_FAULT, faults
    if abnormal:
        return HEALTH_ALERT, abnormal
    if anomaly_flag:
        return REVIEW, ["unusual pattern flagged by anomaly model"]
    return NORMAL, []
