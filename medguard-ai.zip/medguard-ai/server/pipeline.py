"""Ingest pipeline: parse -> authenticate -> replay/freshness -> classify -> store.

Order matters: the HMAC is verified BEFORE any sequence state is touched, so an
unauthenticated attacker cannot advance counters or poison the device state.
"""
from classifier import NORMAL, classify
from security import parse, verify

MAX_SKEW_SECONDS = 60


def _reject(store, kind, device_id, detail, now, code):
    store.add_event(kind, device_id, detail, now)
    return {"status": "rejected", "reason": kind}, code


def process(msg, keys, store, now, max_skew=MAX_SKEW_SECONDS, anomaly_model=None):
    try:
        p = parse(msg)
    except ValueError as exc:
        dev = msg.get("device_id", "?") if isinstance(msg, dict) else "?"
        return _reject(store, "MALFORMED", dev, str(exc), now, 400)

    key = keys.get(p["device_id"])
    if key is None:
        return _reject(store, "UNKNOWN_DEVICE", p["device_id"],
                       "no key registered for device", now, 401)

    if not verify(key, p):
        return _reject(store, "BAD_HMAC", p["device_id"],
                       f"authentication tag mismatch (seq {p['seq']})", now, 401)

    last = store.last_seq(p["device_id"])
    if p["seq"] <= last:
        return _reject(store, "REPLAY", p["device_id"],
                       f"seq {p['seq']} not newer than {last}", now, 409)

    # Buffered messages (sent after an outage) keep their original timestamp,
    # so only live messages are checked for freshness.
    if not p["buffered"] and abs(now - p["ts"]) > max_skew:
        return _reject(store, "STALE_TIMESTAMP", p["device_id"],
                       f"timestamp off by {int(now - p['ts'])} s", now, 409)

    if last >= 0 and p["seq"] > last + 1:
        store.add_event("SEQUENCE_GAP", p["device_id"],
                        f"seq jumped {last} -> {p['seq']} (possible dropped messages)", now)

    anomaly_flag = False
    if anomaly_model is not None:
        try:
            anomaly_flag = int(anomaly_model.predict(
                [[p["hr"], p["spo2"], p["temp"]]])[0]) == -1
        except Exception:
            anomaly_flag = False

    status, reasons = classify(p, anomaly_flag=anomaly_flag)
    detail = "; ".join(reasons)
    store.accept(p, now, status, detail)
    if status != NORMAL:
        store.add_event(status, p["device_id"], detail, now)
    return {"status": "accepted", "classification": status, "reasons": reasons}, 200
