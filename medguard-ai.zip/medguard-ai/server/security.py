"""Message authentication for MedGuard AI.

Each sensor message carries an HMAC-SHA256 tag computed over a canonical
string of its fields. The server recomputes the tag with the device's shared
key; any change to a signed field makes verification fail.

This proves the message is unmodified and came from a holder of the key.
It does NOT prove the physical sensor was not fooled (see docs/threat-model.md).
"""
import hashlib
import hmac
import math
import re

DEVICE_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,32}$")
REQUIRED = ("device_id", "seq", "ts", "hr", "spo2", "temp",
            "motion", "sig_q", "buffered", "hmac")


def parse(msg):
    """Validate and normalise a raw message dict. Raises ValueError if bad.

    The returned values are what gets signed, verified and stored, so a value
    that changes only through int()/round() truncation cannot slip through.
    """
    if not isinstance(msg, dict):
        raise ValueError("body is not a JSON object")
    missing = [k for k in REQUIRED if k not in msg]
    if missing:
        raise ValueError("missing fields: " + ", ".join(missing))
    try:
        temp = float(msg["temp"])
        if not math.isfinite(temp):
            raise ValueError("temp is not finite")
        parsed = {
            "device_id": str(msg["device_id"]),
            "seq": int(msg["seq"]),
            "ts": int(msg["ts"]),
            "hr": int(msg["hr"]),
            "spo2": int(msg["spo2"]),
            "temp": round(temp, 1),
            "motion": int(msg["motion"]),
            "sig_q": int(msg["sig_q"]),
            "buffered": int(msg["buffered"]),
        }
    except (TypeError, ValueError, OverflowError):
        raise ValueError("malformed field value")
    if not DEVICE_ID_RE.match(parsed["device_id"]):
        raise ValueError("invalid device_id")
    if not isinstance(msg["hmac"], str):
        raise ValueError("hmac must be a string")
    parsed["hmac"] = msg["hmac"].strip().lower()
    return parsed


def canonical(p):
    """Canonical string that is signed. Must match firmware exactly."""
    return "|".join([
        p["device_id"], str(p["seq"]), str(p["ts"]), str(p["hr"]),
        str(p["spo2"]), f"{p['temp']:.1f}", str(p["motion"]),
        str(p["sig_q"]), str(p["buffered"]),
    ])


def sign(key, p):
    return hmac.new(key, canonical(p).encode(), hashlib.sha256).hexdigest()


def verify(key, p):
    return hmac.compare_digest(sign(key, p), p["hmac"])
