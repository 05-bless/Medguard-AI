"""MedGuard AI server: ingest endpoint, JSON API and a minimal live dashboard."""
import argparse
import json
import os
import sys
import time

from flask import Flask, jsonify, request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pipeline import MAX_SKEW_SECONDS, process  # noqa: E402
from storage import Storage  # noqa: E402

DASHBOARD = """<!doctype html><html lang="en"><head><meta charset="utf-8">
<title>MedGuard AI dashboard</title><meta name="viewport" content="width=device-width,initial-scale=1">
<style>
body{font-family:Arial,sans-serif;margin:16px;max-width:1000px}
table{border-collapse:collapse;width:100%;margin-bottom:20px;font-size:14px}
th,td{border:1px solid #ccc;padding:6px;text-align:left}th{background:#1f3864;color:#fff}
.NORMAL{background:#e8f5e9}.HEALTH_ALERT,.ALERT_LOW_CONFIDENCE{background:#ffcdd2}
.SENSOR_FAULT,.REVIEW{background:#fff3cd}.BAD_HMAC,.REPLAY,.UNKNOWN_DEVICE,.MALFORMED,.STALE_TIMESTAMP{background:#f8d7da}
.note{color:#555;font-size:13px}
</style></head><body>
<h2>MedGuard AI</h2>
<p class="note">Research prototype, not a medical device. Thresholds are illustrative.</p>
<p>Audit log integrity: <b id="audit">checking...</b></p>
<h3>Latest readings</h3>
<table id="r"><thead><tr><th>Device</th><th>Seq</th><th>HR</th><th>SpO2</th><th>Temp C</th><th>Motion</th><th>Quality</th><th>Buffered</th><th>Status</th></tr></thead><tbody></tbody></table>
<h3>Security and system events</h3>
<table id="e"><thead><tr><th>Time</th><th>Device</th><th>Event</th><th>Detail</th></tr></thead><tbody></tbody></table>
<script>
function fill(id, rows, cols, cls){
  const tb=document.querySelector('#'+id+' tbody'); tb.textContent='';
  rows.forEach(function(r){
    const tr=document.createElement('tr'); tr.className=r[cls];
    cols.forEach(function(c){const td=document.createElement('td'); td.textContent=r[c]; tr.appendChild(td);});
    tb.appendChild(tr);
  });
}
async function refresh(){
  try{
    const r=await (await fetch('/api/readings?limit=15')).json();
    const e=await (await fetch('/api/events?limit=15')).json();
    const a=await (await fetch('/api/audit/verify')).json();
    fill('r',r,['device_id','seq','hr','spo2','temp','motion','sig_q','buffered','status'],'status');
    e.forEach(function(x){x.time=new Date(x.received_at*1000).toLocaleTimeString();});
    fill('e',e,['time','device_id','kind','detail'],'kind');
    document.getElementById('audit').textContent=a.ok?'intact':'TAMPERED (event '+a.first_bad_event+')';
  }catch(err){document.getElementById('audit').textContent='server unreachable';}
}
refresh(); setInterval(refresh,3000);
</script></body></html>"""


def load_keys(path):
    with open(path) as fh:
        return {k: v.encode() for k, v in json.load(fh).items()}


def load_anomaly_model(path):
    try:
        import joblib
        return joblib.load(path) if os.path.exists(path) else None
    except Exception:
        return None


def create_app(db_path=":memory:", keys=None, clock=time.time,
               anomaly_model=None, max_skew=MAX_SKEW_SECONDS):
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = 4096
    store = Storage(db_path)
    app.store = store
    keys = keys or {}

    @app.post("/ingest")
    def ingest():
        body, code = process(request.get_json(silent=True), keys, store,
                             clock(), max_skew, anomaly_model)
        return jsonify(body), code

    @app.get("/api/readings")
    def readings():
        return jsonify(store.recent("readings", request.args.get("limit", 50)))

    @app.get("/api/events")
    def events():
        return jsonify(store.recent("events", request.args.get("limit", 50)))

    @app.get("/api/audit/verify")
    def audit():
        ok, bad = store.verify_chain()
        return jsonify({"ok": ok, "first_bad_event": bad})

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok"})

    @app.get("/")
    def dashboard():
        return DASHBOARD

    return app


if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    ap = argparse.ArgumentParser(description="MedGuard AI server")
    ap.add_argument("--host", default="127.0.0.1",
                    help="use 0.0.0.0 so an ESP32 on your LAN can reach it")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--db", default=os.path.join(here, "medguard.db"))
    ap.add_argument("--keys", default=os.path.join(here, "keys.json"))
    ap.add_argument("--model", default=os.path.join(here, "..", "ml", "models", "isoforest.joblib"))
    args = ap.parse_args()
    if not os.path.exists(args.keys):
        sys.exit("Missing keys file. Copy server/keys.example.json to server/keys.json "
                 "and set a long random key per device.")
    create_app(args.db, load_keys(args.keys),
               anomaly_model=load_anomaly_model(args.model)).run(args.host, args.port)
