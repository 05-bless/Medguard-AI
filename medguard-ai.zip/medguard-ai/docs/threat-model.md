# Threat model

## What the design defends against
| Threat | Defence | Evidence |
|---|---|---|
| Value changed in transit | HMAC-SHA256 tag over all fields | `test_modified_value_rejected` |
| Captured message resent | Strictly increasing sequence number per device | `test_replayed_message_rejected` |
| Old live message resent later | Timestamp freshness window (live messages) | `test_stale_timestamp_rejected_when_live` |
| Forged messages from unknown device | Per-device keys | `test_unknown_device_rejected` |
| Attacker advancing counters | Tag checked before any state changes | `test_rejected_message_does_not_advance_sequence` |
| Log edited or rows deleted | Hash-chained event log | `test_audit_chain_*` |

## What it does NOT defend against
- **A physically fooled sensor.** HMAC protects the message, not the finger on the sensor.
- **A compromised device.** Anyone holding the key can sign false data.
- **Eavesdropping.** The prototype sends JSON over HTTP. Use TLS for any real deployment.
- **Denial of service** (jamming Wi-Fi, flooding the server). Local alerts keep working, but remote alerts do not.
- **Key extraction from flash.** Enable ESP32 flash encryption, and consider a variant with an eFuse-backed HMAC peripheral.

## Assumptions
- Keys are provisioned securely and never committed to the repository.
- Server clock is roughly correct (NTP). Live messages must be within 60 seconds.
