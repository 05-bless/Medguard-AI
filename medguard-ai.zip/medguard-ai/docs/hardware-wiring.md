# Hardware and wiring (prototype)

| Part | Connection | ESP32 pin |
|---|---|---|
| MAX30102 | I2C SDA / SCL, 3.3 V, GND | GPIO 21 / GPIO 22 |
| MPU6050 | Shared I2C bus, 3.3 V, GND | GPIO 21 / GPIO 22 |
| DS18B20 | Data with 4.7 k pull-up to 3.3 V | GPIO 4 |
| Buzzer | Through a transistor or active buzzer module | GPIO 25 |
| Green LED | With 220 ohm resistor | GPIO 26 |
| Red LED | With 220 ohm resistor | GPIO 27 |

Check your module's voltage rating before connecting. Add a photo of your finished wiring to this folder.

## Bill of materials
Fill in from your supplier. Keep one supplier so the total is traceable.

| Item | Qty | Unit price (Rs) | Source link |
|---|---|---|---|
| ESP32 dev board | 1 | | |
| MAX30102 module | 1 | | |
| DS18B20 | 1 | | |
| MPU6050 | 1 | | |
| Buzzer, LEDs, resistors, wires | 1 set | | |
| **Total** | | | |
