# Architecture

```mermaid
flowchart LR
  S[MAX30102 / DS18B20 / MPU6050] --> E[ESP32]
  E -->|signed JSON over Wi-Fi| P[Ingest pipeline]
  E -. local alerts .-> B[Buzzer and LEDs]
  subgraph Server
    P --> A{HMAC valid?}
    A -- no --> X[Security event log]
    A -- yes --> R{Fresh and in sequence?}
    R -- no --> X
    R -- yes --> C[Classifier + optional Isolation Forest]
    C --> D[(SQLite readings)]
    C --> X
  end
  D --> W[Flask dashboard]
  X --> W
```

## Three-layer trust decision
| Layer | Question | Module |
|---|---|---|
| 1. Security | Is the message authentic, fresh and in order? | `server/security.py`, `server/pipeline.py` |
| 2. Sensor quality | Is the reading reliable or affected by motion? | `server/classifier.py` |
| 3. Health | Does a validated reading look abnormal? | `server/classifier.py`, `ml/` |

**Safety rule:** an uncertain reading never suppresses a possible health alert. A suspect and abnormal reading is reported as `ALERT_LOW_CONFIDENCE`.

## Message format
JSON fields: `device_id, seq, ts, hr, spo2, temp, motion, sig_q, buffered, hmac`.

The HMAC-SHA256 tag covers this canonical string (temperature with one decimal):

```
device_id|seq|ts|hr|spo2|temp|motion|sig_q|buffered
```

## Offline operation
- The ESP32 raises local alerts regardless of the network.
- Readings are queued while offline and sent oldest first after reconnection, marked `buffered=1` with their original timestamp.
- Buffered messages skip the freshness check but still need a valid tag and a newer sequence number.
- The sequence counter is stored in flash and does not depend on the clock.

## Audit log
Each security event stores the hash of the previous event. `GET /api/audit/verify` recomputes the chain and reports the first edited or missing row.
