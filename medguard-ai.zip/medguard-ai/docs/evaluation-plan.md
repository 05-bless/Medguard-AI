# Evaluation plan

Report measured results, with how each was measured.

| Metric | How to measure | Software result | Hardware result |
|---|---|---|---|
| Tampered messages detected | `python tests/bench_detection.py` | see README | to measure |
| Replayed messages detected | `python tests/bench_detection.py` | see README | to measure |
| False alerts on labelled data | Run the pipeline on a labelled set | to measure | to measure |
| Detection-to-display time | Timestamp send and dashboard update | to measure | to measure |
| Buffered messages recovered | Unplug network, send N, reconnect, count | to measure | to measure |
| Sensor accuracy | Compare with a commercial fingertip oximeter | n/a | to measure |

Software results simulate the server pipeline only. They exclude real sensors, radio loss and network latency.
