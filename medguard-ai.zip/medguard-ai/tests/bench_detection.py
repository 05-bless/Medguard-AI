"""Measure detection rates and per-message processing time (software only).

These are simulation results for the server pipeline. They do NOT include
real sensors, radio loss or network latency, so report them as such.

Run from the repo root:  python tests/bench_detection.py [N]
"""
import copy
import os
import random
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "server"))
sys.path.insert(0, os.path.dirname(__file__))

from app import create_app  # noqa: E402
from helpers import DEVICE, KEY, NOW, make_msg  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
random.seed(1)
app = create_app(keys={DEVICE: KEY}, clock=lambda: NOW)
c = app.test_client()


def post(m):
    return c.post("/ingest", json=m).status_code


genuine, accepted, tampered_caught, replay_caught = [], 0, 0, 0
times = []
for i in range(1, N + 1):
    m = make_msg(i, hr=random.randint(60, 100), spo2=random.randint(95, 100))
    t0 = time.perf_counter()
    code = post(m)
    times.append((time.perf_counter() - t0) * 1000)
    accepted += code == 200
    genuine.append(m)

for m in random.sample(genuine, N // 2):
    t = copy.deepcopy(m)
    field = random.choice(["hr", "spo2", "temp", "motion", "sig_q", "seq", "ts"])
    t[field] = t[field] + random.choice([1, 5, 40, 100])
    tampered_caught += post(t) in (401, 409)

for m in random.sample(genuine, N // 2):
    replay_caught += post(m) == 409

times.sort()
print(f"Messages sent: {N} genuine, {N // 2} tampered, {N // 2} replayed (software simulation)")
print(f"Genuine accepted:          {accepted}/{N}")
print(f"Tampered messages caught:  {tampered_caught}/{N // 2}")
print(f"Replayed messages caught:  {replay_caught}/{N // 2}")
print(f"Median processing time:    {times[len(times) // 2]:.2f} ms")
print(f"95th percentile:           {times[int(len(times) * 0.95)]:.2f} ms")
print("Audit log integrity:       ", "intact" if app.store.verify_chain()[0] else "TAMPERED")
