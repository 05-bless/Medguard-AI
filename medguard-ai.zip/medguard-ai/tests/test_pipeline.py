import pytest
from app import create_app
from helpers import DEVICE, KEY, NOW, make_msg


@pytest.fixture
def client():
    app = create_app(keys={DEVICE: KEY}, clock=lambda: NOW)
    c = app.test_client()
    c.store = app.store
    return c


def post(c, msg):
    r = c.post("/ingest", json=msg)
    return r.status_code, r.get_json()


def kinds(c):
    return [e["kind"] for e in c.store.recent("events")]


def test_valid_message_accepted(client):
    code, body = post(client, make_msg(1))
    assert code == 200 and body["classification"] == "NORMAL"


def test_modified_value_rejected(client):
    """The demo case: heart rate 76 -> 180 without updating the tag."""
    msg = make_msg(1)
    msg["hr"] = 180
    code, body = post(client, msg)
    assert code == 401 and body["reason"] == "BAD_HMAC"
    assert "BAD_HMAC" in kinds(client)


def test_replayed_message_rejected(client):
    msg = make_msg(1)
    assert post(client, msg)[0] == 200
    code, body = post(client, msg)
    assert code == 409 and body["reason"] == "REPLAY"


def test_older_sequence_rejected(client):
    assert post(client, make_msg(5))[0] == 200
    assert post(client, make_msg(3))[0] == 409


def test_stale_timestamp_rejected_when_live(client):
    code, body = post(client, make_msg(1, ts=NOW - 600))
    assert code == 409 and body["reason"] == "STALE_TIMESTAMP"


def test_buffered_message_with_old_timestamp_accepted(client):
    code, _ = post(client, make_msg(1, ts=NOW - 600, buffered=1))
    assert code == 200


def test_flipping_buffered_flag_breaks_tag(client):
    msg = make_msg(1, ts=NOW - 600, buffered=0)
    msg["buffered"] = 1
    assert post(client, msg)[1]["reason"] == "BAD_HMAC"


def test_wrong_key_rejected(client):
    code, body = post(client, make_msg(1, key=b"attacker-guess"))
    assert code == 401 and body["reason"] == "BAD_HMAC"


def test_unknown_device_rejected(client):
    code, body = post(client, make_msg(1, device_id="rogue-99"))
    assert code == 401 and body["reason"] == "UNKNOWN_DEVICE"


def test_malformed_rejected(client):
    assert post(client, {"device_id": DEVICE})[0] == 400
    assert client.post("/ingest", data="not json").status_code == 400


def test_rejected_message_does_not_advance_sequence(client):
    bad = make_msg(50)
    bad["hr"] = 150
    post(client, bad)
    assert post(client, make_msg(1))[0] == 200


def test_sequence_gap_is_logged_but_accepted(client):
    post(client, make_msg(1))
    code, _ = post(client, make_msg(10))
    assert code == 200 and "SEQUENCE_GAP" in kinds(client)


def test_health_alert(client):
    _, body = post(client, make_msg(1, hr=150))
    assert body["classification"] == "HEALTH_ALERT"


def test_motion_is_sensor_fault_not_health_alert(client):
    _, body = post(client, make_msg(1, motion=1))
    assert body["classification"] == "SENSOR_FAULT"


def test_uncertain_abnormal_reading_still_alerts(client):
    """Safety rule: a bad-quality reading must not silence a possible emergency."""
    _, body = post(client, make_msg(1, hr=150, motion=1, sig_q=20))
    assert body["classification"] == "ALERT_LOW_CONFIDENCE"


def test_audit_chain_intact_then_detects_tampering(client):
    msg = make_msg(1)
    msg["hr"] = 180
    post(client, msg)
    post(client, make_msg(2, ts=NOW - 600))
    assert client.get("/api/audit/verify").get_json()["ok"] is True
    client.store.conn.execute("UPDATE events SET detail='edited' WHERE id=1")
    result = client.get("/api/audit/verify").get_json()
    assert result["ok"] is False and result["first_bad_event"] == 1


def test_deleting_an_event_breaks_chain(client):
    for i in range(3):
        m = make_msg(i + 1)
        m["hr"] = 180
        post(client, m)
    client.store.conn.execute("DELETE FROM events WHERE id=2")
    assert client.get("/api/audit/verify").get_json()["ok"] is False
