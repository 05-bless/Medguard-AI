"""Shared helpers: build and sign messages the way the firmware does."""
from security import sign

KEY = b"test-key-not-for-production"
DEVICE = "esp32-01"
NOW = 1_800_000_000


def make_msg(seq=1, ts=NOW, key=KEY, **overrides):
    p = {"device_id": DEVICE, "seq": seq, "ts": ts, "hr": 76, "spo2": 98,
         "temp": 36.6, "motion": 0, "sig_q": 90, "buffered": 0}
    p.update(overrides)
    p["hmac"] = sign(key, p)
    return p
