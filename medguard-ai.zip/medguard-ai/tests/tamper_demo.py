"""Live demo: shows the three attack cases the judges will ask about.

Run from the repo root:  python tests/tamper_demo.py
No hardware or running server needed.
"""
import copy
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "server"))
sys.path.insert(0, os.path.dirname(__file__))

from app import create_app  # noqa: E402
from helpers import DEVICE, KEY, NOW, make_msg  # noqa: E402

app = create_app(keys={DEVICE: KEY}, clock=lambda: NOW)
client = app.test_client()


def send(label, msg):
    r = client.post("/ingest", json=msg)
    body = r.get_json()
    outcome = body.get("classification") or body.get("reason")
    print(f"{label:<44} HTTP {r.status_code}  {body['status']:<9} {outcome}")


print("MedGuard AI - tamper and replay demo (software only)\n")
genuine = make_msg(1, hr=76)
send("1. Genuine message (heart rate 76)", genuine)

tampered = make_msg(2, hr=76)
tampered["hr"] = 180
send("2. Heart rate changed 76 -> 180, tag untouched", tampered)

send("3. Genuine message replayed", genuine)
send("4. Abnormal reading with motion (still alerts)",
     make_msg(3, hr=150, motion=1, sig_q=20))
send("5. Buffered message after outage (old timestamp)",
     make_msg(4, ts=NOW - 900, buffered=1))

ok, bad = app.store.verify_chain()
print(f"\nAudit log integrity: {'intact' if ok else 'TAMPERED at event ' + str(bad)}")
print("Security events logged:",
      ", ".join(e["kind"] for e in reversed(app.store.recent("events"))))
