# Security policy

MedGuard AI is a research and hackathon prototype, **not a medical device**. It must not be used for patient-care decisions.

## Reporting a vulnerability
Please open a private security advisory on GitHub (Security tab, "Report a vulnerability") or email the maintainers. Do not post exploit details in public issues.

## Handling secrets
- Never commit `server/keys.json` or `firmware/medguard_esp32/config.h`. Both are git-ignored.
- Use a different long random key for every device.
- If a key is ever committed, treat it as leaked: rotate it and rewrite the history.

## Known limitations
See [docs/threat-model.md](docs/threat-model.md). In short: message authentication does not protect against a physically fooled sensor, a compromised device that holds the key, or traffic analysis, and the prototype's HTTP transport should be replaced with TLS before any real deployment.
